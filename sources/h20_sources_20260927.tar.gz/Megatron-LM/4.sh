#!/bin/bash
#SBATCH -J megatron
#SBATCH -p gpu
#SBATCH --qos=gpugpu
#SBATCH -N 2
#SBATCH --gres=gpu:8
#SBATCH -o logs/%j.out
#SBATCH -e logs/%j.err
#SBATCH -x g[0613,0863],g[0603,0659]

export NCCL_DEBUG=INFO
export NCCL_IB_DISABLE=0
export NCCL_IB_HCA=mlx5_2:1
export NCCL_SOCKET_IFNAM

# master_addr使用主节点
export MASTER_ADDR=$(scontrol show hostnames $SLURM_JOB_NODELIST | head -n 1)
export MASTER_PORT=$((RANDOM % 101 + 20000))
export GPUS_PER_NODE=$SLURM_GPUS_ON_NODE
export NNODES=$SLURM_NNODES
source /etc/profile.d/modules.sh
#source ~/run/wjy/set.sh
source /data/home/scvj012/run/mbbq/env.sh
module load cuda/12.8
module load miniforge/25.3.0-3
module load zip/6.10
module load cmake/3.31.8
module load openssl/3.0.2
#module load nccl/2.26.5-1_cuda12.8
module load nccl/2.27.6-1_cuda12.8
source  /data/apps/miniforge/25.3.0-3/bin/activate py312-t29
export PYTHONNOUSERSITE=1
echo "MASTER_ADDR=$MASTER_ADDR"
echo "MASTER_PORT=$MASTER_PORT"
echo "NNODES=$NNODES"
echo "GPUS_PER_NODE=$GPUS_PER_NODE"
echo "NODELIST=$SLURM_JOB_NODELIST"

srun --ntasks=$SLURM_NNODES --ntasks-per-node=1 \
     bash -c "export NODE_RANK=\$SLURM_PROCID; \
              export MASTER_ADDR=$MASTER_ADDR; \
              export MASTER_PORT=$MASTER_PORT; \
              export GPUS_PER_NODE=$GPUS_PER_NODE; \
              export NNODES=$NNODES; \
              echo \"Node \$SLURM_PROCID: MASTER_ADDR=\$MASTER_ADDR,NODE_RANK=\$NODE_RANK\"; \
              ./Test_Auto/llama/MM_llama32_3b.sh"
