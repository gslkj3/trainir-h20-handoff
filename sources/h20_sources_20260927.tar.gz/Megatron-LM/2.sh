#!/bin/bash
#SBATCH -J Megatron_MM_llama32_3b
#SBATCH -p gpu
#SBATCH --qos=gpugpu
#SBATCH -N 2
#SBATCH --gres=gpu:8
#SBATCH -o logs/MM_llama32_3b_%j.out
#SBATCH -e logs/MM_llama32_3b_%j.err
#SBATCH -x g[0613,0863],g[0603,0659]

# 获取节点列表
nodes=($(scontrol show hostnames $SLURM_JOB_NODELIST))
MASTER_ADDR=${nodes[0]}
NODES=2
GPUS_PER_NODE=8

# 设置环境变量
export MASTER_ADDR=$MASTER_ADDR
export MASTER_PORT=29503
export NNODES=$NODES
export GPUS_PER_NODE=$GPUS_PER_NODE

echo "Job started at: $(date)"
echo "Master node: $MASTER_ADDR"
echo "Node list: ${nodes[@]}"
echo "Number of nodes: $NODES"

# 加载必要的模块
source /etc/profile.d/modules.sh
module load miniforge cuda/12.8 cudnn/9.6.0.74_cuda12 nccl/2.26.5-1_cuda12.8

# 激活conda环境
source /data/apps/miniforge/25.3.0-3/bin/activate py311-mindspeed

# 设置库路径
export LD_LIBRARY_PATH=/data/apps/cuda/12.8/extras/CUPTI/lib64/:$LD_LIBRARY_PATH
export CUDNN_PATH=/data/apps/cudnn/9.6.0.74_cuda12
export CUDNN_HOME=/data/apps/cudnn/9.6.0.74_cuda12
export LD_LIBRARY_PATH=/data/apps/cudnn/9.6.0.74_cuda12/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/data/apps/nccl/2.26.5-1_cuda12.8/build/lib:$LD_LIBRARY_PATH

# 设置NCCL相关环境变量
export NCCL_DEBUG=INFO
export NCCL_IB_DISABLE=0
export NCCL_IB_HCA=mlx5_2:1
export NCCL_SOCKET_IFNAME=bond0
export CUDA_DEVICE_MAX_CONNECTIONS=1

# 切换到工作目录
cd /data/home/scvj012/run/wjy/Megatron-LM

# 删除之前的日志文件
rm -rf train_rank*

# 在主节点上运行
echo "Starting rank 0 on node $MASTER_ADDR"
./Test_Auto/llama/MM_llama32_3b.sh $MASTER_ADDR 0 $NODES &

# 在第二个节点上通过ssh运行
node2=${nodes[1]}
echo "Starting rank 1 on node $node2"
ssh $node2 "cd /data/home/scvj012/run/wjy/Megatron-LM && ./Test_Auto/llama/MM_llama32_3b.sh $MASTER_ADDR 1 $NODES" &

# 等待所有进程完成
wait

echo "Job completed at: $(date)"