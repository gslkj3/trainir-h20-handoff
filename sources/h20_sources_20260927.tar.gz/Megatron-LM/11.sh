#!/bin/bash
#SBATCH -J Megatron
#SBATCH -p gpu
#SBATCH --qos=gpugpu
#SBATCH -N 2
#SBATCH --gres=gpu:8
##SBATCH -o logs/nccl_test/AutoPara_llama32_3b.out
###SBATCH -e logs/nccl_test/AutoPara_llama32_3b.err

# master_addr使用主节点
NODES=2
nodes=($(scontrol show hostnames $SLURM_JOB_NODELIST))
node1=${nodes[0]}
MASTER_ADDR=${nodes[0]}
node2=${nodes[1]}
GPUS=8
RANK_SCRIPT="22.sh"

rm -rf train_rank*
bash ${RANK_SCRIPT} ${MASTER_ADDR} 0 $NODES &

ssh $node2 "cd /data/home/scvj012/run/wjy/Megatron-LM  && bash ${RANK_SCRIPT} ${MASTER_ADDR} 1 ${NODES}" &
wait




