#!/usr/bin/env python3
"""Build a canonical, deterministic real-training ranking suite."""
import argparse
import hashlib
import json
import os
from pathlib import Path


def load(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def gqa_enabled(row):
    value = row.get("strategy", {}).get("Hybrid_MHA_MQA", [False, None])
    return bool(value[0]) if isinstance(value, (list, tuple)) and value else False


def canonicalize(row, num_layers):
    row = json.loads(json.dumps(row))
    parallel = row["parallel"]
    pp = int(parallel[1])
    strategy = row.setdefault("strategy", {})
    vpp = strategy.get("VirtualPipe")
    if vpp not in (None, 0, "None"):
        vpp = int(vpp)
        if pp <= 1 or num_layers % (pp * vpp) != 0 or num_layers <= pp * vpp:
            strategy["VirtualPipe"] = None
    return row


def config_key(row):
    return json.dumps(
        {"parallel": row["parallel"], "strategy": row.get("strategy", {})},
        sort_keys=True,
        separators=(",", ":"),
    )


def deduplicate(rows):
    unique = {}
    for row in rows:
        key = config_key(row)
        if key not in unique or float(row["predicted_cost"]) < float(unique[key]["predicted_cost"]):
            unique[key] = row
    return list(unique.values())


def evenly_spaced_indices(start, stop, count):
    """Return count unique inclusive indices over [start, stop]."""
    if count <= 0:
        return []
    if count == 1:
        return [start]
    raw = [round(start + i * (stop - start) / (count - 1)) for i in range(count)]
    out = []
    for idx in raw:
        if idx not in out:
            out.append(idx)
    for idx in range(start, stop + 1):
        if len(out) >= count:
            break
        if idx not in out:
            out.append(idx)
    return sorted(out[:count])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", help="Full DTSIR ranking JSONL manifest")
    parser.add_argument("output", help="Output real-training suite JSONL")
    parser.add_argument("--n", type=int, default=30)
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--num-layers", type=int, default=int(os.getenv("DTSIR_NUM_LAYERS", "8")))
    parser.add_argument("--allow-gqa", action="store_true", help="Allow quality-changing GQA candidates")
    args = parser.parse_args()

    if args.n < 2 or not 1 <= args.top_k <= args.n:
        raise SystemExit("Require n >= 2 and 1 <= top-k <= n")

    rows = [
        canonicalize(row, args.num_layers)
        for row in load(args.input)
        if row.get("predicted_cost") is not None and row.get("parallel")
    ]
    if not args.allow_gqa:
        rows = [row for row in rows if not gqa_enabled(row)]
    rows = deduplicate(rows)
    rows.sort(key=lambda row: float(row["predicted_cost"]))
    if len(rows) < args.n:
        raise SystemExit(f"Need {args.n} eligible unique candidates, found {len(rows)}")

    top_count = min(args.top_k, args.n)
    selected_indices = list(range(top_count))
    selected_indices += evenly_spaced_indices(top_count, len(rows) - 1, args.n - top_count)
    selected_indices = sorted(dict.fromkeys(selected_indices))
    if len(selected_indices) != args.n:
        raise SystemExit(f"Internal selection error: expected {args.n}, got {len(selected_indices)}")

    chosen = []
    for suite_rank, source_idx in enumerate(selected_indices, 1):
        row = json.loads(json.dumps(rows[source_idx]))
        key = config_key(row)
        row["candidate_id"] = "ranking_" + hashlib.sha1(key.encode()).hexdigest()[:10]
        row["suite_role"] = "ranking_accuracy"
        row["source_predicted_rank"] = source_idx + 1
        row["suite_predicted_rank"] = suite_rank
        chosen.append(row)

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in chosen),
        encoding="utf-8",
    )
    print(f"Eligible unique candidates: {len(rows)}")
    print(f"Selected candidates: {len(chosen)} (predicted top-{top_count} plus stratified coverage)")
    print(f"Source rank range: {selected_indices[0] + 1}--{selected_indices[-1] + 1}")
    print(f"Manifest: {output}")


if __name__ == "__main__":
    main()
