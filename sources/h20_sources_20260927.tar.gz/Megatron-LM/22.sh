#!/bin/bash
source /etc/profile.d/modules.sh
cd /data/home/scvj012/run/wjy/Megatron-LM
export CUDA_DEVICE_MAX_CONNECTIONS=${CUDA_DEVICE_MAX_CONNECTIONS:-1}
module load miniforge cuda/12.8 cudnn/9.6.0.74_cuda12 nccl/2.26.5-1_cuda12.8
source /data/apps/miniforge/25.3.0-3/bin/activate py310-t27
export LD_LIBRARY_PATH=/data/apps/cuda/12.8/extras/CUPTI/lib64/:$LD_LIBRARY_PATH
export GPUS_PER_NODE=8
export NNODES=$SLURM_NNODES
export NCCL_DEBUG=INFO
export NCCL_IB_DISABLE=0
export NCCL_IB_HCA=mlx5_2:1
export NCCL_SOCKET_IFNAME=bond0
export CUDNN_PATH=/data/apps/cudnn/9.6.0.74_cuda12
export CUDNN_HOME=/data/apps/cudnn/9.6.0.74_cuda12
export LD_LIBRARY_PATH=/data/apps/cudnn/9.6.0.74_cuda12/lib:$LD_LIBRARY_PATH

MASTER_ADDR=$1
MASTER_PORT=29503
GPUS_PER_NODE=8
NNODES=${NNODES:-2}
NODE_RANK=$2
NUM_NODES=$3
TP_SIZE=4
PP_SIZE=1
WORLD_SIZE=$(($GPUS_PER_NODE * $NNODES))
DP_SIZE=$((${WORLD_SIZE} / ${TP_SIZE} / ${PP_SIZE}))
MICRO_BATCH_SIZE=1
GRADIENT_ACCUMULATION_STEPS=4
GLOBAL_BATCH_SIZE=$(($DP_SIZE * $MICRO_BATCH_SIZE * $GRADIENT_ACCUMULATION_STEPS))

echo "MASTER_ADDR=$MASTER_ADDR"
echo "MASTER_PORT=$MASTER_PORT"
echo "NNODES=$SLURM_NNODES"
echo "NODELIST=$SLURM_JOB_NODELIST"
echo "GPUS_PER_NODE=$GPUS_PER_NODE"


DATA_PATH="/data/home/scvj012/run/wjy/Megatron-LM/dataset/llama3/enwiki_text_document"
TOKENIZER_MODEL="/data/home/scvj012/run/wjy/Megatron-LM/model_from_hf/llama3-hf"
TP=4
PP=1

DISTRIBUTED_ARGS="
    --nproc_per_node $GPUS_PER_NODE \
    --nnodes $NUM_NODES \
    --node_rank $NODE_RANK \
    --master_addr $MASTER_ADDR \
    --master_port $MASTER_PORT
"

GPT_ARGS="
    --tensor-model-parallel-size $TP_SIZE \
    --pipeline-model-parallel-size $PP_SIZE \
    --use-mcore-models \
    --micro-batch-size $MICRO_BATCH_SIZE \
    --global-batch-size $GLOBAL_BATCH_SIZE \
    --sequence-parallel \
    --attention-backend auto  \
    --use-rotary-position-embeddings \
    --rope-scaling-factor 32.0 \
    --tokenizer-type HuggingFaceTokenizer \
    --tokenizer-model ${TOKENIZER_MODEL} \
    --num-layers 28 \
    --hidden-size 3072 \
    --ffn-hidden-size 8192 \
    --num-attention-heads 24 \
    --group-query-attention \
    --num-query-groups 8 \
    --seq-length 2048 \
    --max-position-embeddings 4096 \
    --make-vocab-size-divisible-by 1 \
    --disable-bias-linear \
    --attention-dropout 0.0 \
    --init-method-std 0.01 \
    --hidden-dropout 0.0 \
    --position-embedding-type rope \
    --rotary-base 500000 \
    --normalization RMSNorm \
    --norm-epsilon 1e-5 \
    --swiglu \
    --no-masked-softmax-fusion \
    --attention-softmax-in-fp32 \
    --lr 1.25e-6 \
    --train-iters 10 \
    --lr-decay-style cosine \
    --min-lr 1.25e-7 \
    --weight-decay 1e-1 \
    --lr-warmup-fraction 0.01 \
    --clip-grad 1.0 \
    --adam-beta1 0.9 \
    --adam-beta2 0.95 \
    --initial-loss-scale 4096 \
    --use-distributed-optimizer \
    --no-gradient-accumulation-fusion \
    --no-load-optim \
    --no-load-rng \
    --bf16
"

DATA_ARGS="
    --data-path $DATA_PATH \
    --split 10,0,0
"

OUTPUT_ARGS="
    --log-interval 1 \
    --save-interval 10 \
    --eval-interval 10 \
    --eval-iters 0 \
"
MAX_RETRIES=3
RETRY_COUNT=0

LOGFILE="log_tp${TP_SIZE}_pp${PP_SIZE}_gbs${GLOBAL_BATCH_SIZE}_${NODE_RANK}.log"
export LD_LIBRARY_PATH=/data/apps/nccl/2.26.5-1_cuda12.8/build/lib:$LD_LIBRARY_PATH
source /etc/profile.d/modules.sh
module load  cuda/12.8 cudnn/9.6.0.74_cuda12 nccl/2.26.5-1_cuda12.8
torchrun ${DISTRIBUTED_ARGS[@]} pretrain_gpt.py \
    ${DATA_ARGS[@]} ${OUTPUT_ARGS[@]} ${GPT_ARGS[@]}  > $LOGFILE 2>&1


echo $SLURM_NNODES
