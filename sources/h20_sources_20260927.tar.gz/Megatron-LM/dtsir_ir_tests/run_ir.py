"""Run from Megatron root; all child jobs run sequentially on the same 4 GPUs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def cases():
    rows = []
    for family in ('tp_gqa', 'pp_recompute', 'tp_distopt'):
        for role, a, b in (('base',0,0),('A',1,0),('B',0,1),('AB',1,1)):
            pp = (4 if a else 2) if family == 'pp_recompute' else (2 if family == 'tp_gqa' else 1)
            tp = 2 if a and family != 'pp_recompute' else 1
            dp = 4//(pp*tp)
            strategy = {'VirtualPipe': None, 'DistributedOptimizer': bool(b and family=='tp_distopt'),
                'Hybrid_MHA_MQA': [bool(b and family=='tp_gqa'), 8 if b and family=='tp_gqa' else 32],
                'ReCompute': ['selective',['mlp']] if b and family=='pp_recompute' else [None,None]}
            rows.append({'candidate_id': family+'_'+role, 'family': family, 'role': role,
                         'parallel': [dp,pp,1,1,tp,1,1,2,256//(dp*2)], 'strategy': strategy})
    return rows



def skip_rejected_candidate(root, row):
    pred_path = root/'predict_0'/'prediction.json'
    status_path = root/'predict_0'/'status.json'
    if not pred_path.exists() or not status_path.exists():
        return False
    if not json.loads(status_path.read_text()).get('ok'):
        return False
    pred = json.loads(pred_path.read_text())
    if pred.get('candidate') != row:
        raise SystemExit(f'Prediction candidate mismatch: {pred_path}')
    if pred.get('feasible') is not False:
        return False
    evidence = []
    for status in sorted(root.glob('*/status.json')):
        if status.parent.name == 'predict_0':
            continue
        record = json.loads(status.read_text())
        if record.get('ok'):
            evidence.append({'job': status.parent.name, 'outcome': 'completed'})
            continue
        log = status.with_name('console.log')
        text = log.read_text(errors='replace') if log.exists() else ''
        if record.get('exit_code') in (None, 0, -1) or 'torch.OutOfMemoryError: CUDA out of memory' not in text:
            raise SystemExit(f'Unclassified existing failure; inspect before continuing: {status.parent}')
        evidence.append({'job': status.parent.name, 'outcome': 'cuda_oom'})
    decision = {
        'candidate': row['candidate_id'],
        'predicted_feasible': False,
        'predicted_peak_bytes': pred.get('predicted_peak_bytes'),
        'action': 'skip_remaining_training_for_predicted_infeasible_candidate',
        'existing_training_evidence': evidence,
        'note': 'Original logs/status files preserved. Skipping is not a successful training run; partial OOM observations are not completed-training peaks.'
    }
    (root/'resume_decision.json').write_text(json.dumps(decision, indent=2))
    print('skip predicted-infeasible', row['candidate_id'], evidence, flush=True)
    return True


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--launcher', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--smoke', action='store_true')
    p.add_argument('--repeats', type=int, default=3)
    p.add_argument('--timeout', type=int, default=1800)
    ns = p.parse_args()
    out = Path(ns.out).resolve(); out.mkdir(parents=True, exist_ok=True)
    launcher = Path(ns.launcher).resolve()
    rows = cases()[:1] if ns.smoke else cases()
    contract = {'cases': rows, 'launcher_sha256': hashlib.sha256(launcher.read_bytes()).hexdigest(),
                'repeats': 1 if ns.smoke else ns.repeats}
    manifest = out/'run_contract.json'
    if manifest.exists() and json.loads(manifest.read_text()) != contract:
        raise SystemExit('Output directory belongs to a different run; use a new directory.')
    manifest.write_text(json.dumps(contract,indent=2))
    failures = []
    for row in rows:
        jobs = [('predict',0),('observe',0)] + [('clean',r) for r in range(contract['repeats'])]
        for mode, rep in jobs:
            if mode != 'predict' and skip_rejected_candidate(out/row['candidate_id'], row):
                break
            job = out/row['candidate_id']/f'{mode}_{rep}'; job.mkdir(parents=True,exist_ok=True)
            status = job/'status.json'
            if status.exists():
                old = json.loads(status.read_text())
                if old.get('ok'):
                    print('skip',job,flush=True); continue
                raise SystemExit(f'Previous failed job: {job}. Inspect log before retrying into a new output directory.')
            env = os.environ.copy()
            for key in list(env):
                if key.startswith('DTSIR_') or key == 'AUTOMM': env.pop(key)
            env.update({'DTSIR_EXPERIMENT':'measure','DTSIR_IR_FIXED':str(int(mode=='predict')),
                'DTSIR_IR_OBSERVE':str(int(mode=='observe')), 'DTSIR_IR_OUT':str(job),
                'DTSIR_MEASURE_CANDIDATE_JSON':json.dumps(row), 'GPUS_PER_NODE':'4','NNODES':'1',
                'NODE_RANK':'0','PYTHONUNBUFFERED':'1',
                'DTSIR_COMPENSATION_NOTE':os.environ.get('DTSIR_COMPENSATION_NOTE','User-reported environment compensation; details pending'),
                'DTSIR_MML_LOGS':os.environ.get('DTSIR_MML_LOGS', str(Path('mm_logs').resolve()))})
            print(row['candidate_id'],mode,rep,flush=True)
            start = time.time()
            with (job/'console.log').open('w') as log:
                proc = subprocess.Popen(['bash','-o','pipefail',str(launcher)],env=env,
                                        stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                try: code = proc.wait(timeout=ns.timeout)
                except (subprocess.TimeoutExpired, KeyboardInterrupt):
                    os.killpg(proc.pid,signal.SIGTERM)
                    try: proc.wait(timeout=15)
                    except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL); proc.wait()
                    code = -1
            artifact = (job/'prediction.json').exists() if mode=='predict' else (len(list(job.glob('rank*_observations.json')))==4 if mode=='observe' else True)
            ok = code==0 and artifact
            status.write_text(json.dumps({'exit_code':code,'ok':ok,'wall_seconds':time.time()-start,'mode':mode}))
            if not ok:
                failures.append(str(job)); break
        if failures: break
    subprocess.run([sys.executable,str(Path(__file__).with_name('summarize_ir.py')),str(out)],check=True)
    if failures: raise SystemExit('Stopped on failure: '+failures[0])


if __name__ == '__main__': main()
