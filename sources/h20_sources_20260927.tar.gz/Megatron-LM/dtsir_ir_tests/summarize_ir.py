import csv
import json
from pathlib import Path
import re
import statistics
import sys


def summarize(out):
    rows=[]
    for case in json.loads((out/'run_contract.json').read_text())['cases']:
        root=out/case['candidate_id']
        prediction=root/'predict_0'/'prediction.json'
        pred=json.loads(prediction.read_text()) if prediction.exists() else {}
        runs=[]; sample_counts=[]
        for log in sorted(root.glob('clean_*/console.log')):
            status=log.with_name('status.json')
            if not status.exists() or not json.loads(status.read_text()).get('ok'): continue
            values=[float(v) for v in re.findall(r'elapsed time per iteration\s*\(ms\)\s*:\s*([\d.]+)',log.read_text(errors='replace'))]
            sample_counts.append(len(values))
            # Do not silently summarize an incomplete ten-iteration training run.
            if len(values)>=10: runs.append(statistics.mean(values[1:10]))
        decision_path=root/'resume_decision.json'
        decision=json.loads(decision_path.read_text()) if decision_path.exists() else {}
        observe_status=root/'observe_0'/'status.json'
        observe_ok=json.loads(observe_status.read_text()).get('ok',False) if observe_status.exists() else False
        observations=[json.loads(x.read_text()) for x in root.glob('observe_0/rank*_observations.json')]
        rows.append({'candidate':case['candidate_id'],'family':case['family'],'role':case['role'],
            'predicted_feasible':pred.get('feasible'), 'predicted_peak_bytes':pred.get('predicted_peak_bytes'),
            'predicted_cost_native_units':pred.get('predicted_cost_native_units'),
            'clean_completed_repeats':len(runs),'iteration_samples':str(sample_counts),
            'clean_iteration_ms':statistics.mean(runs) if runs else None,
            'repeat_stdev_ms':statistics.stdev(runs) if len(runs)>1 else None,
            'observed_ranks':len(observations),
            'observe_completed':observe_ok,
            'resume_action':decision.get('action'),
            'existing_training_evidence':json.dumps(decision.get('existing_training_evidence', [])),
            'observed_process_peak_allocated_bytes':max((x['process_peak_allocated_bytes'] for x in observations),default=None) if observe_ok else None})
    with (out/'summary.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader();writer.writerows(rows)
    interaction=[]
    for family in sorted({r['family'] for r in rows}):
        group={r['role']:r for r in rows if r['family']==family}
        if all(k in group and group[k]['clean_iteration_ms'] is not None for k in ('base','A','B','AB')):
            additive=group['A']['clean_iteration_ms']+group['B']['clean_iteration_ms']-group['base']['clean_iteration_ms']
            actual=group['AB']['clean_iteration_ms']
            interaction.append({'family':family,'additive_iteration_ms':additive,'measured_AB_ms':actual,
                                'interaction_residual_ms':actual-additive})
    (out/'interaction.json').write_text(json.dumps(interaction,indent=2))
    (out/'README_results.txt').write_text('summary.csv is preliminary. Prediction units and process-lifetime memory scope require alignment before computing model errors. No automatic communication/replay match is asserted. Send the entire directory, including failed runs.\n')
    print('Saved',out/'summary.csv')


if __name__=='__main__': summarize(Path(sys.argv[1]))
