import unittest
import json
import tempfile
from pathlib import Path
from run_ir import cases
from summarize_ir import summarize

class ContractTests(unittest.TestCase):
    def test_count_identity(self):
        self.assertEqual(len(cases()),12)
        self.assertEqual(len({x['candidate_id'] for x in cases()}),12)
    def test_batch_and_devices(self):
        for x in cases():
            dp,pp,cp,up,tp,sp,ep,mb,n=x['parallel']
            self.assertEqual(dp*pp*tp,4)
            self.assertTrue(all(int(v) >= 1 for v in x['parallel']))
            self.assertEqual(sp,1)
            self.assertEqual(dp*mb*n,256)
            self.assertEqual(8%pp,0)
            self.assertEqual(x['strategy']['Hybrid_MHA_MQA'][1]%tp,0)
    def test_baselines(self):
        for x in cases():
            if x['role']=='base':
                self.assertFalse(x['strategy']['DistributedOptimizer'])
                self.assertFalse(x['strategy']['Hybrid_MHA_MQA'][0])
                self.assertEqual(x['strategy']['ReCompute'],[None,None])
    def test_summary_synthetic_fixture(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            selected=cases()[:4]
            (root/'run_contract.json').write_text(json.dumps({'cases':selected}))
            for row,value in zip(selected,(100,90,80,65)):
                job=root/row['candidate_id']/'clean_0';job.mkdir(parents=True)
                (job/'status.json').write_text(json.dumps({'ok':True}))
                (job/'console.log').write_text(('elapsed time per iteration (ms): '+str(value)+'\n')*10)
            summarize(root)
            result=json.loads((root/'interaction.json').read_text())
            self.assertEqual(result[0]['additive_iteration_ms'],70)
            self.assertEqual(result[0]['interaction_residual_ms'],-5)

if __name__=='__main__':unittest.main()
