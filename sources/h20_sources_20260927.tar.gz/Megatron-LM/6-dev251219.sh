#!/bin/bash
#SBATCH -J deepseek2_8k
#SBATCH -N 2
#SBATCH -p gpu
#SBATCH --qos=gpugpu
#SBATCH --gres=gpu:8
#SBATCH -o logs/deepseek2_8k-%j.log
#SBATCH -e logs/deepseek2_8k-%j.log
#SBATCH -x g[0603],g[0611],g[0599]
#SBATCH
export AUTOMM=0
export FILE="deepseek/deepseek2_8k.sh"
export MASTER_ADDR=$(scontrol show hostnames | head -n 1)
export MASTER_PORT=$((RANDOM % 101 + 20000))
echo "检查主节点${MASTER_ADDR}端口${MASTER_PORT}是否被占用"
lsof -i:${MASTER_PORT}
if [ $? -eq 0 ]; then
    echo "Port $MASTER_PORT is already in use. Please choose a different port."
    exit 1
fi
GPUS_PER_NODE=`nvidia-smi -L | wc -l`

echo "在每个节点上运行命令"
let node_rank=0
for node in $(scontrol show hostnames)
do
    echo "Running on $node"
    echo "日志保存到logs/slurm-${SLURM_JOB_ID}-rank_${node_rank}-node_${node}.log"
    LOG_FILE="logs/slurm-${SLURM_JOB_ID}-rank_${node_rank}-node_${node}.log"
    if [[ $node != $(scontrol show hostnames|tail -n 1) ]]; then
        srun -N 1 --gres=gpu:"${GPUS_PER_NODE}" -w "${node}" \
            bash -c "\
                export MASTER_ADDR=${MASTER_ADDR}; \
                export MASTER_PORT=${MASTER_PORT}; \
                export NODE_RANK=${node_rank}; \
                export NNODES=${SLURM_NNODES}; \
                export AUTOMM=${AUTOMM}; \
                source 4env-dev251219.sh; \
                ./Test_Auto/${FILE}" \
        1>$LOG_FILE 2>&1 &
    else
        srun -N 1 --gres=gpu:"${GPUS_PER_NODE}" -w "${node}" \
            bash -c "\
                export MASTER_ADDR=${MASTER_ADDR}; \
                export MASTER_PORT=${MASTER_PORT}; \
                export NODE_RANK=${node_rank}; \
                export NNODES=${SLURM_NNODES}; \
                export AUTOMM=${AUTOMM}; \
                source 4env-dev251219.sh; \
                ./Test_Auto/${FILE}" \
        1>$LOG_FILE 2>&1
    fi
    let node_rank=node_rank+1
done
