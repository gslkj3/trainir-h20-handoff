"""Read-only collection for exact common-space integration; stdlib, no GPU."""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile
import time

CASES = ['llama7b_2k', 'llama2_7b_4k', 'llama2_13b_4k',
         'llama3_8b_8k', 'qwen3_14b_4k']


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--megatron', default='/data/run01/scxi681/wjy/Megatron-LM')
    ap.add_argument('--galvatron', default='/data/run01/scxi681/wjy/dependencies/Hetu-Galvatron-dtsir')
    a = ap.parse_args()
    roots = {'megatron': Path(a.megatron).resolve(), 'galvatron': Path(a.galvatron).resolve()}
    for r in roots.values():
        if not r.is_dir():
            raise SystemExit('Missing repository: '+str(r))
    out = roots['megatron']/'mm_logs'/('common5_protocol_audit_'+time.strftime('%Y%m%d_%H%M%S')+'_'+str(time.time_ns()%1000000))
    out.mkdir(parents=True, exist_ok=False)
    manifest = []
    def copy(p, label):
        if not p.is_file():
            return
        dest = out/label/p.relative_to(roots[label])
        dest.parent.mkdir(parents=True, exist_ok=True)
        data = p.read_bytes()
        dest.write_bytes(data)
        manifest.append({'system': label, 'path': str(p.relative_to(roots[label])),
                         'sha256': hashlib.sha256(data).hexdigest(), 'bytes':len(data)})
    # Copy source, not installed packages, model weights, credentials or datasets.
    patterns = {
        'megatron': ['test_parallel_model.py', 'dtsir_collect.py',
                    'dtsir_common16/**/*.py', 'dtsir_common16/**/*.sh',
                    'dtsir_common16/**/*.json', 'paired16/*.py', 'paired16/*.sh',
                    'paired16/*.sbatch', 'megatron/training/initialize.py'],
        'galvatron': ['galvatron/core/search_engine/**/*.py',
                     'galvatron/core/search_engine/**/*.cpp',
                     'galvatron/core/search_engine/**/*.h',
                     'galvatron/core/profiler/**/*.py',
                     'galvatron/core/runtime/args_schema.py',
                     'galvatron/core/runtime/optimizer/*.py',
                     'galvatron/utils/config_utils.py',
                     'galvatron/utils/strategy_utils.py',
                     'galvatron/utils/hf_config_adapter.py',
                     'dtsir_galvatron6/*.py', 'dtsir_galvatron6/*.sh',
                     'dtsir_galvatron6/*.json']}
    for label, pats in patterns.items():
        paths = set()
        for pat in pats:
            paths.update(roots[label].glob(pat))
        for p in sorted(paths):
            copy(p,label)
        # Latest complete evidence is not assumed: record recent attempts separately.
        for case in CASES:
            candidates = []
            for parent in (roots[label]/'mm_logs').iterdir():
                if parent.is_dir() and not parent.name.startswith(('failed3_', 'common5_protocol_audit_')):
                    c = parent/case
                    if c.is_dir():
                        candidates.append(c)
            candidates.sort(key=lambda p:p.stat().st_mtime, reverse=True)
            for c in candidates[:3]:
                for name in ['summary.json','status.json','contract.json','run_contract.json',
                             'runtime.yaml','search_args.json','training_summary.json',
                             'environment.json','search/search.json','search/status.json']:
                    copy(c/name,label)
                for p in c.glob('rank*_effective.json'):
                    copy(p,label)
                for p in c.glob('clean_*/rank*_effective.json'):
                    copy(p,label)
                for p in c.glob('selected/*.json'):
                    copy(p,label)
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (out/'scope.json').write_text(json.dumps({'cases':CASES,'world_size':16,
        'excluded':['qwen2_1p5b_32k','qwen2_7b_32k','qwen25_14b_8k'],
        'note':'Collection only. No search, training or source modification.'},indent=2))
    archive = Path(str(out)+'.tar.gz')
    with tarfile.open(archive,'w:gz') as tf:
        tf.add(out,arcname=out.name)
    print('FILES:',len(manifest))
    print('SEND THIS FILE:',archive)


if __name__=='__main__':
    main()
