#!/bin/bash

echo "设置自定义参数"
CONDA_ENV_NAME=py312-t29
echo "-------------------------------------------------"
echo "CONDA_ENV_NAME:  $CONDA_ENV_NAME"
echo "-------------------------------------------------"

echo "enviroment modules配置"
echo "-------------------------------------------------"
module purge
module load cuda/12.8 nccl/2.27.6-1_cuda12.8
module list
echo "-------------------------------------------------"

echo "conda环境激活"
source /data/apps/miniforge/25.3.0-3/etc/profile.d/conda.sh
conda activate $CONDA_ENV_NAME
echo "-------------------------------------------------"
echo "conda environment: $CONDA_PREFIX"
echo "python:            $(which python)"
echo "python version:    $(python --version)"
echo "-------------------------------------------------"

echo "分布式参数配置"
export GPUS_PER_NODE=`nvidia-smi -L|wc -l`
export NCCL_DEBUG=INFO
export NCCL_IB_DISABLE=0
export NCCL_IB_HCA=mlx5_2:1
export NCCL_SOCKET_IFNAME=bond0
export GLOO_SOCKET_IFNAME=bond0
export NCCL_TIMEOUT=10800
export NCCL_IB_TIMEOUT=22
export NCCL_ASYNC_ERROR_HANDLING=1

echo "-------------------------------------------------"
echo "检查bond0接口"
ip a | grep bond0
if [ $? -eq 0 ]; then
    echo "bond0接口存在"
# else
#     echo "bond0接口不存在"
#     export NCCL_SOCKET_IFNAME=eth0
#     export GLOO_SOCKET_IFNAME=eth0
fi
echo "-------------------------------------------------"

echo "-------------------------------------------------"
echo "MASTER_ADDR:        $MASTER_ADDR"
echo "MASTER_PORT:        $MASTER_PORT"
echo "GPUS_PER_NODE:      $GPUS_PER_NODE"
echo "NCCL_SOCKET_IFNAME: $NCCL_SOCKET_IFNAME"
echo "NCCL_IB_HCA:        $NCCL_IB_HCA"
echo "NCCL_IB_DISABLE:    $NCCL_IB_DISABLE"
echo "NCCL_DEBUG:         $NCCL_DEBUG"
echo "HOSTNAME:           $HOSTNAME"
echo "NNODES:             $NNODES"
echo "NODE_RANK:          $NODE_RANK"
echo "-------------------------------------------------"

