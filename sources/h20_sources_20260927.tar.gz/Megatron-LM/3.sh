#!/bin/bash
#SBATCH -J megatron
#SBATCH -p gpu
#SBATCH --qos=gpugpu
#SBATCH -N 1
#SBATCH --gres=gpu:8
#SBATCH -o logs/%j.out
#SBATCH -e logs/%j.err
#SBATCH -x g[0613,0863],g[0603,0659]

# master_addr使用主节点
export MASTER_ADDR=$(scontrol show hostnames $SLURM_JOB_NODELIST | head -n 1)
export MASTER_PORT=$((RANDOM % 101 + 20000))
export GPUS_PER_NODE=$SLURM_GPUS_ON_NODE
export NNODES=$SLURM_NNODES

source /data/home/scvj012/run/mbbq/env.sh

echo "MASTER_ADDR=$MASTER_ADDR"
echo "MASTER_PORT=$MASTER_PORT"
echo "NNODES=$NNODES"
echo "GPUS_PER_NODE=$GPUS_PER_NODE"
echo "NODELIST=$SLURM_JOB_NODELIST"

srun --ntasks=$SLURM_NNODES --ntasks-per-node=1 \
     bash -c "export NODE_RANK=\$SLURM_PROCID; \
              export MASTER_ADDR=$MASTER_ADDR; \
              export MASTER_PORT=$MASTER_PORT; \
              export GPUS_PER_NODE=$GPUS_PER_NODE; \
              export NNODES=$NNODES; \
              echo \"Node \$SLURM_PROCID: MASTER_ADDR=\$MASTER_ADDR,NODE_RANK=\$NODE_RANK\"; \
              ./Test_Auto/llama/AutoPara_llama_7b.sh"
