#!/usr/bin/env python3
"""Select five semantically comparable candidates from a DTSIR ranking manifest."""
import argparse, hashlib, json, math, os
from pathlib import Path

def load(path):
    return [json.loads(x) for x in Path(path).read_text(encoding="utf-8").splitlines() if x.strip()]

def gqa_enabled(row):
    value=row.get("strategy",{}).get("Hybrid_MHA_MQA",[False,None])
    return bool(value[0]) if isinstance(value,(list,tuple)) and value else False

def pair(row):
    p=row["parallel"]
    return int(p[4]),int(p[1])  # TP, PP

def canonicalize(row,num_layers):
    row=json.loads(json.dumps(row))
    p=row["parallel"]; pp=int(p[1]); strategy=row.setdefault("strategy",{})
    vpp=strategy.get("VirtualPipe")
    if vpp not in (None,0,"None"):
        vpp=int(vpp)
        if pp<=1 or num_layers%(pp*vpp)!=0 or num_layers<=pp*vpp:
            strategy["VirtualPipe"]=None
    return row

def deduplicate(rows):
    out={}
    for row in rows:
        key=json.dumps({"parallel":row["parallel"],"strategy":row.get("strategy",{})},sort_keys=True)
        if key not in out or float(row["predicted_cost"])<float(out[key]["predicted_cost"]): out[key]=row
    rows=list(out.values())
    for row in rows:
        key=json.dumps({"parallel":row["parallel"],"strategy":row.get("strategy",{})},sort_keys=True)
        row["candidate_id"]="sanity_"+hashlib.sha1(key.encode()).hexdigest()[:10]
    return rows

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--allow-gqa",action="store_true",help="Allow quality-changing GQA candidates")
    ap.add_argument("--num-layers",type=int,default=int(os.getenv("DTSIR_NUM_LAYERS","8")))
    args=ap.parse_args()
    rows=[canonicalize(r,args.num_layers) for r in load(args.input) if r.get("predicted_cost") is not None and r.get("parallel")]
    if not args.allow_gqa:
        rows=[r for r in rows if not gqa_enabled(r)]
    rows=deduplicate(rows)
    rows.sort(key=lambda r:float(r["predicted_cost"]))
    if len(rows)<5:
        raise SystemExit(f"Need at least 5 eligible candidates, found {len(rows)}")
    ranks=[0,min(2,len(rows)-1),len(rows)//2,len(rows)-1]
    chosen=[]
    roles=["predicted_best","predicted_top3","predicted_middle","predicted_poor"]
    for idx,role in zip(ranks,roles):
        row=dict(rows[idx]); row["sanity_role"]=role; row["predicted_rank"]=idx+1
        if row.get("candidate_id") not in {x.get("candidate_id") for x in chosen}: chosen.append(row)
    used={x.get("candidate_id") for x in chosen}; used_pairs={pair(x) for x in chosen}
    best_pair=pair(rows[0])
    alternatives=[(i,r) for i,r in enumerate(rows) if r.get("candidate_id") not in used and pair(r)!=best_pair]
    alternatives.sort(key=lambda x:(pair(x[1]) in used_pairs, x[0]))
    if not alternatives: raise SystemExit("No candidate with a distinct TP/PP pair")
    i,row=alternatives[0]; row=dict(row); row["sanity_role"]="distinct_tp_pp"; row["predicted_rank"]=i+1; chosen.append(row)
    Path(args.output).write_text("".join(json.dumps(r,ensure_ascii=False)+"\n" for r in chosen),encoding="utf-8")
    for r in chosen:
        print(f"{r['sanity_role']:>18} rank={r['predicted_rank']:>4} cost={float(r['predicted_cost']):.6g} TP/PP={pair(r)} id={r.get('candidate_id')}")

if __name__=="__main__": main()
