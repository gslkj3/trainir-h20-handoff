# 单节点四卡冒烟补丁

覆盖仅限新建的dtsir_common16测试包：run.py、entry.py、worker.sh、env.sh、test_package.py；新增submit/smoke4.sbatch。不要覆盖项目根目录test_parallel_model.py、dtsir_collect.py或megatron/training/initialize.py。保留自己已经修改的数据路径cases.json，以及六个正式提交文件。

直接读取原来跑通的dtsir_ir_tests/MM_llama_7b.sh，保留其数据、tokenizer、模型参数和后端选项；仅在结果目录产生入口替换副本，不修改原.sh。预期原模型为8层、hidden4096、FFN11008、heads32、seq2048、GBS256、FP16，搜索固定32KV头、MBS1/2、DP/TP/PP、其他优化关闭。

仅申请1节点4张5090；执行一次搜索和所选配置的一次10步clean训练，不做三次重复、不做额外observe。新结果位于mm_logs/common16_v1/smoke4/，与旧四卡实验及六个正式模型结果隔离。

```bash
cd ~/run/wjy/Megatron-LM
conda activate py312-t29
mkdir -p logs
python dtsir_common16/test_package.py
bash -n dtsir_common16/submit/smoke4.sbatch
python dtsir_common16/run.py --case smoke4 --check-only
sbatch dtsir_common16/submit/smoke4.sbatch
```

任务获得资源后：

```bash
squeue -u "$USER"
cat mm_logs/common16_v1/smoke4/summary.json
tar -czf common_smoke4_results.tar.gz -C mm_logs/common16_v1 smoke4
```

成功条件：search/status.json为completed，summary.json有best，clean_0/status.json为completed，十步训练完整，四份rank*_effective.json与候选一致。

四卡只验证Slurm单节点启动、新公共空间驱动、预测选择和训练下发；不能验证跨节点网络、16卡通信校准和完整模型容量。单节点使用loopback并禁用IB，此项不用于推断16卡通信性能。双节点正式任务仍使用原bond0/mlx5_2策略。

默认正式模型仍为两节点八卡及三次训练，没有修改其模型或提交资源。由于驱动代码有变化，如果已经产生旧版正式结果，原合同检查会拒绝混用；请保留旧结果后再处理，不删除记录。不在旧驱动正在运行时覆盖文件。

本补丁经过本地逻辑检查，未在GPU服务器运行。无需安装任何新包。
