# 六例 × 双节点16卡：Devastator/Megatron侧公共空间测试 v1

## 安装位置：只新增，不覆盖

把本包整个内容放到 Megatron-LM/dtsir_common16/，确保 run.py 位于 dtsir_common16/run.py。无需覆盖当前已跑通的 test_parallel_model.py、dtsir_collect.py 或 megatron/training/initialize.py。请不要把本包放到另一层同名目录中。

每个submit/*.sbatch申请hp_5090、qos=gpugpu、2节点、每节点8GPU，共16卡，保留用户的集群环境方式。提交目录必须是Megatron-LM根目录。批任务通过一个srun运行两个节点任务，各节点各启动一次8进程torch distributed run，统一检查退出码。

## 六例与固定参数

| ID | 用例 | 层数 | 序列 | GBS | 精度 | KV头 |
|---|---|---:|---:|---:|---|---:|
|llama7b_2k|LLaMA-7B-2K|32|2048|256|FP16|32|
|llama2_7b_4k|LLaMA2-7B-4K|32|4096|256|FP16|32|
|llama2_13b_4k|LLaMA2-13B-4K|40|4096|512|FP16|40|
|llama3_8b_8k|LLaMA3-8B-8K|32|8192|64|BF16|8|
|qwen2_1p5b_32k|Qwen2-1.5B-32K|28|32768|64|BF16|2|
|qwen3_14b_4k|Qwen3-14B-4K|40|4096|128|BF16|8|

模型数学参数和精度取自用户AutoPara testcase；不是缩成8层。Qwen3保留QK normalization和128维KV channel。用户原Qwen2脚本使用qwen3目录的tokenizer和数据，本包保留这一路径关系，但不能据此断言模型/数据已经与Galvatron对齐；后续须双方核对词表及tokenizer。

## 搜索协议

DP/TP/PP，TP允许1、2、4、8且满足头数/布局可整除约束；均匀流水线层划分；microbatch为1、2、4、8，保持各用例GBS；保留项目既有microbatch数量不小于PP等合法性约束。SP关闭，CP/UP/EP=1，重计算、VPP、优化器分片、grad-reduce/param-gather overlap关闭，GQA固定为模型值。保留原脚本FlashAttention等固定后端设置。搜索每一级配置使用项目现有GPT内存/代价模型，不改变用户DP通信补偿。

这只是Devastator/Megatron侧的预先声明协议，不代表已证实Galvatron能完全表达全部模型和候选。后续Galvatron必须核对DP实现、均匀/非均匀PP、batch、数学结构、后端等；若协议必须改变，须明确版本并重跑受影响一侧，不能直接宣称已严格隔离规划器差异。

证据为各用例从当前mm_logs/calc_data和comm_data复制的独立暖启动快照；缺失算子实测仍会产生新测量，记录其开销。不是冷启动总时间。节点内/节点间通信校准必须适合本次16卡拓扑；文件存在不等于校准覆盖正确。已有4卡校准是否涵盖跨节点需核查，不能把缺失/无效通信类型解释为零成本。

## 提交前检查

1. 如当前数据目录不在Megatron-LM/dataset或model_from_hf，编辑cases.json中的data_path和tokenizer_path。数据路径是.bin/.idx的共同前缀，不要带后缀。默认根据旧脚本改为当前项目相对路径，不再包含旧用户名。
2. env.sh使用用户提供的cuda/12.8、nccl/2.27.6-1_cuda12.8、py312-t29，以及bond0/mlx5_2:1。不进行安装或猜测替代网卡。检查失败就停止。
3. 使用原已跑通环境，先执行以下不申请GPU的本地检查：

```bash
cd ~/run/wjy/Megatron-LM
conda activate py312-t29
mkdir -p logs
bash dtsir_common16/check_all.sh
```

检查全部通过后，每个脚本独立提交：

```bash
sbatch dtsir_common16/submit/llama7b_2k.sbatch
sbatch dtsir_common16/submit/llama2_7b_4k.sbatch
sbatch dtsir_common16/submit/llama2_13b_4k.sbatch
sbatch dtsir_common16/submit/llama3_8b_8k.sbatch
sbatch dtsir_common16/submit/qwen2_1p5b_32k.sbatch
sbatch dtsir_common16/submit/qwen3_14b_4k.sbatch
```

建议先提交llama7b_2k，确认双节点启动成功，再提交其余五个，避免相同环境错误占用多份资源。提交不等于立即分配卡，实际受配额和排队影响。

## 结果与续跑

结果固定写到mm_logs/common16_v1/<ID>/。一次搜索后选预测最优，执行三次10步训练，去首步汇总。记录原候选集合、预测代价、计数、配置、每rank参数、节点环境和训练日志。无可行候选写best=null，不启动训练；winner OOM保留失败，不自动替换第二名；其他报错停止。

同一脚本再次sbatch会跳过已有完成任务或已记录的OOM。失败/中断文件不自动覆盖，RUNNING.lock用于阻止重复驱动；如Slurm强制终止导致锁残留，先发日志确认旧作业已结束，不要直接删锁或结果。输入/代码/种子变化会拒绝混入原实验。

```bash
squeue -u "$USER"
cat mm_logs/common16_v1/llama7b_2k/summary.json
tar -czf common16_megatron_results.tar.gz -C mm_logs common16_v1
```

本包通过本地Python语法和逻辑测试，未在用户双节点GPU集群运行。服务器check_all.sh补做bash语法/路径检查。性能结果必须以实际日志为准。没有用allocated峰值计算总显存预测精度。
