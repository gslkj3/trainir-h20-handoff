import ast
import json
from pathlib import Path
import tempfile
import unittest
from entry import strategy
from run import execute, specs, measured_iteration_s

ROOT=Path(__file__).resolve().parent
class Checks(unittest.TestCase):
    def test_single_run_and_tail_five(self):
        self.assertTrue(all(s['repeats']==1 for s in specs().values()))
        self.assertEqual(measured_iteration_s({'iteration_ms':[9000]*5+[1000,2000,3000,4000,5000]}),3.0)
        with self.assertRaises(ValueError):
            measured_iteration_s({'iteration_ms':[1000]*9})
    def test_python_syntax(self):
        for f in ROOT.glob('*.py'):ast.parse(f.read_text())
    def test_six_specs(self):
        data=specs();self.assertEqual(len(data),7)
        for name,s in data.items():
            if name=='smoke4':
                self.assertEqual(s['nodes']*s['gpus_per_node'],4)
                self.assertEqual(s['repeats'],1)
                self.assertEqual(s['existing_launcher'],'dtsir_ir_tests/MM_llama_7b.sh')
                continue
            self.assertEqual(s['global_batch_size']%16,0)
            self.assertEqual(s['mbs'],[1,2,4,8])
            self.assertTrue((ROOT/'submit'/f'{name}.sbatch').exists())
            text=(ROOT/'launchers'/f'{name}.sh').read_text()
            self.assertEqual(text.count('dtsir_common16/entry.py'),1)
            self.assertNotIn('scvj012',text)
            self.assertIn('python -m torch.distributed.run',text)
    def test_fixed_model_structure(self):
        s=specs()['qwen2_1p5b_32k'];st=strategy(s)
        self.assertEqual(st['Hybrid_MHA_MQA'],[True,2])
        self.assertFalse(st['DistributedOptimizer'])
        self.assertEqual(st['ReCompute'],[None,None])
    def test_resume_skips_success_without_srun(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'status.json').write_text(json.dumps({'outcome':'completed'}))
            self.assertEqual(execute(p,{},1,False)['outcome'],'completed')
    def test_resume_skips_oom(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'status.json').write_text(json.dumps({'outcome':'oom'}))
            self.assertEqual(execute(p,{},1,False)['outcome'],'oom')
    def test_failure_not_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'status.json').write_text(json.dumps({'outcome':'failed'}))
            with self.assertRaises(RuntimeError):execute(p,{},1,False)

if __name__=='__main__':unittest.main()
