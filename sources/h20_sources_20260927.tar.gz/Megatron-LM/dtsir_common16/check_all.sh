#!/bin/bash
set -eo pipefail
for name in llama7b_2k llama2_7b_4k llama2_13b_4k llama3_8b_8k qwen2_1p5b_32k qwen3_14b_4k; do
    bash -n "dtsir_common16/submit/${name}.sbatch"
    bash -n "dtsir_common16/launchers/${name}.sh"
    python dtsir_common16/run.py --case "$name" --check-only
done
bash -n dtsir_common16/env.sh
bash -n dtsir_common16/worker.sh
python dtsir_common16/test_package.py
echo 'All local checks passed. This does not verify GPU/NCCL execution or Galvatron support.'
