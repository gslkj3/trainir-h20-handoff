import torch
print(f"PyTorch CUDA可用: {torch.cuda.is_available()}")
print(f"PyTorch编译时使用的CUDA版本: {torch.version.cuda}")
print(f"PyTorch检测到的CUDA设备: {torch.cuda.device_count()}")
